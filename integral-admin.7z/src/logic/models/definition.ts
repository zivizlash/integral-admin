
export type User = {
  id: number;
  login: string;
  role: number;
};
